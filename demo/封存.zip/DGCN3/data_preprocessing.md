
# 📊 数据预处理模块说明（`data.py`）

本模块主要完成动态图节点传播重要性预测任务中数据的预处理与加载。核心目标是：  
从原始的动态图边列表文件与对应的 SIR 仿真结果中，构建用于图神经网络训练的 PyTorch Geometric 格式数据。

---

## 🔧 函数功能概述

### `compute_D_features(G: nx.Graph, num_nodes: int) -> torch.Tensor`

计算全图中每个节点的三种 **度特征**：

- **D1**: 节点自身的度
- **D2**: 节点的度 + 所有邻居的度
- **D3**: 节点的 D2 + 所有邻居的 D2

这些特征用于表示节点的局部连接情况，并进行 Min-Max 归一化。

---

### `compute_community_D_features(G: nx.Graph, communities: List[Set[int]], num_nodes: int) -> torch.Tensor`

计算 **社区内部的度特征** D1~D3，与 `compute_D_features` 相似，但仅在社区子图中计算。用于建模社区结构对节点的重要性影响。

---

### `compute_H_features(G: nx.Graph, num_nodes: int) -> torch.Tensor`

计算全图中每个节点的 **H-index 传播结构特征**：

- **H1**: 节点的邻居度分布所决定的 H-index
- **H2**: 节点所有邻居的 H1 总和
- **H3**: 节点所有二阶邻居的 H2 总和

反映了节点在不同层级结构中的传播能力。

---

### `compute_community_H_features(G: nx.Graph, communities: List[Set[int]], num_nodes: int) -> torch.Tensor`

与 `compute_H_features` 类似，在社区子图中计算 H1~H3，用于建模社区内部结构影响。

---

### `preprocess_raw_data(...)`

#### 功能：
对每个时间步的动态图快照进行以下操作：

1. **读取边列表和 SIR 文件**
2. 构建 `networkx.Graph` 对象
3. 计算五类特征：
   - 单位矩阵 One-Hot（唯一标识）
   - 全图 D 特征
   - 社区内 D 特征
   - 全图 H 特征
   - 社区内 H 特征
4. **SIR 标签加载**
5. **构造 PyTorch Geometric 的 `Data` 对象**
6. 保存为 pickle 文件（每个时间步一个文件）

#### 输入参数说明：

| 参数名                | 含义                         |
|---------------------|----------------------------|
| `raw_dataset_dir`   | 原始动态图边文件目录          |
| `processed_dataset_dir` | 输出的处理后数据存储路径       |
| `sir_results_base_dir` | SIR 模拟结果根目录             |
| `a`                 | 传播率参数（用于匹配 SIR 文件） |

---

### `get_data(...) -> Tuple[List[Data], List[int], List[int]]`

#### 功能：
加载已处理的 pickle 数据，划分为训练集和测试集，返回每个时间步的图对象。

#### 返回：
- `dataset`: 所有时间步的 `Data` 对象列表
- `train_timesteps`: 训练用的时间步编号
- `test_timesteps`: 测试用的时间步编号

#### 参数说明：

| 参数名             | 含义                           |
|------------------|------------------------------|
| `dataset_name`   | 数据集文件夹名（例如 `HT09`）    |
| `train_test_ratio` | 测试集比例（如 0.3）            |
| `device`         | 数据将使用的设备（如 `cuda`）    |
| `a`              | SIR 模拟参数                    |

---

## 🔄 数据处理流程图

```mermaid
flowchart TD
    A[读取原始边文件] --> B[构建图 G]
    B --> C[计算全图结构特征 D, H]
    C --> D[社团检测]
    D --> E[计算社区结构特征 D, H]
    E --> F[读取 SIR 标签]
    F --> G[构建 PyG Data 对象]
    G --> H[保存为 pickle 文件]
    H --> I[被 get_data() 加载并划分训练/测试集]
```

---

## 🧠 最终特征拼接

每个节点的最终特征如下：

```text
x = [one-hot | D1 D2 D3 | comm_D1 D2 D3 | H1 H2 H3 | comm_H1 H2 H3]
维度 = num_nodes + 12
```

---

## 🧪 示例：处理并加载 `HT09` 数据集

```python
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dataset, train_timesteps, test_timesteps = get_data(
    dataset_name="HT09",
    train_test_ratio=0.3,
    device=device,
    a=0.1
)
```

---

如需可视化某一时间步的数据：

```python
from torch_geometric.utils import to_networkx
import matplotlib.pyplot as plt

G = to_networkx(dataset[0])
nx.draw(G, with_labels=True)
plt.show()
```
